<script>
  import './style.css';

  import fil from "./data.json";
  let json = JSON.parse(JSON.stringify(fil));
  let tabell = []

  for (let i = 0; i < json.length; i++) {
      tabell = [...tabell, {kategori: json[i].kategori,
      team: json[i].team,
      navn: json[i].navn,
      pris: json[i].pris,
      bilde: json[i].bilde,
      credlink: json[i].credlink,
      credtxt: json[i].credtxt,
      credlink2: json[i].credlink2,
      credtxt2: json[i].credtxt2,
      place: json[i].place
  }];
  };

  let selectedCategory = 'sjåfør';
  let searchQuery = '';

  tabell.sort((a, b) => (a.kategori - b.kategori))

  $: filteredItems = tabell.filter(item => item.kategori === selectedCategory && item.navn.toLowerCase().includes(searchQuery.toLowerCase()));

  function updateCategory(category) {
    selectedCategory = category;
  }

  function fillTable() {
    // Create a new row and append it to the table
    const tr = document.createElement('tr');
    tr.id = "tr";
    const table = document.getElementById("tabell");
    table.appendChild(tr);

    // Get the selected option and the quantity input
    const bestill = document.getElementById("bestill");
    const mengde = document.getElementById("mengde");
    const selectedOption = bestill.options[bestill.selectedIndex];
    const vare = selectedOption.text.split(", ")[0];
    const price = selectedOption.text.split(", ")[1];
    const quantity = mengde.value;

    // Create new table cells and append them to the row
    const td1 = document.createElement('td');
    td1.innerHTML = vare;
    tr.appendChild(td1);

    const td2 = document.createElement('td');
    td2.innerHTML = price;
    tr.appendChild(td2);

    const td3 = document.createElement('td');
    td3.innerHTML = quantity;
    tr.appendChild(td3);
  }

  function heim() {
    window.location.href = "heim";
  }
  function sjåførar() {
    window.location.href = "sjåførar";
  }
  function tilbehør() {
    window.location.href = "tilbehør";
  }
  function badevatn() {
    window.location.href = "badevatn";
  }
  function bilar() {
    window.location.href = "bilar";
  }
</script>

<header>
  <div class="title">
    <img src="/img/Logo.png" alt="Logo" />
    <h1>F<i>1</i> A<i>ccesories</i></h1>
  </div>
  <div class="lines">
    <div>
      <div class="line1"></div>
      <div class="line2"></div>
      <div class="line3"></div>
    </div>
  </div>
</header>
<nav>
  <button on:click={heim}><img class="icon" src="/img/heim.png" alt="">Heim<img class="icon" src="/img/heim.png" alt=""></button> 
    <button on:click={sjåførar} ><img class="icon" src="/img/vroom.png" alt="">Sjåførar<img class="icon" src="/img/vroom.png" alt=""></button>
    <button on:click={tilbehør}><img class="icon" src="/img/acc.png" alt="">Tilbehør<img class="icon" src="/img/acc.png" alt=""></button>
    <button on:click={badevatn}><img class="icon" src="/img/bottle.png" alt="">Badevatn<img class="icon" src="/img/bottle.png" alt=""></button>
    <button on:click={bilar}><img class="icon" src="/img/bil.png" alt="">Bilar<img class="icon" src="/img/bil.png" alt=""></button>  
</nav>
<main>
  <div class="margin">
    <div class="search">
      <div>
          <input type="text" placeholder="Søk..." bind:value={searchQuery}>
      </div>
      
      
  </div>
      <hr>
      <div class="cardcon">
          {#each filteredItems as rad}
          <div class="card">
              <br>
              <img src={rad.bilde} alt="" class="pic"><br>
              <div class="creds">
              <a class="smallp" href={rad.credlink}>{rad.credtxt}</a>
              <a class="smallp" href={rad.credlink2}>{rad.credtxt2}</a>
              <p class="smallp">, {rad.place}</p>
          </div>
          <h4>{rad.navn}</h4>
          <p class="pris">{rad.pris} kr</p>
          <br>

          </div>
          
          {/each}
          </div>
</main>
<footer>
  <div class="footer">
    <p>© 2023 F1 Accesories</p>
  </div>
</footer>